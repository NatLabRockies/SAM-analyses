1. 32.87_-117.15_32.87_-117.15_nsrdb-GOES-aggregated-v4-0-0_60_2018.csv
    sam csv

2. comp.xlsx
    excel workbook comparing sam csv (inputs) to e+ outputs

3. eplusout.csv
    raw e+ outputs

4. eplusout.err
    energyplus error file (clean, shows no issues, would show epw problems)

5. epw.py
    script that reads in sam csv and creates epw

6. idf.py
    script that reads in min.idf and adds site location for e+ to run

7. in.epw
    output of epw.py

8. in.idf
    output of idf.py

9. min.idf
    minimal idf used to test generated epw