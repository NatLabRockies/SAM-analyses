import pandas as pd
import openstudio

# read first row of sam csv 
sam_csv = '32.87_-117.15_32.87_-117.15_nsrdb-GOES-aggregated-v4-0-0_60_2018.csv'
info_df = pd.read_csv(sam_csv, nrows=1)

# get info for site location idf object
locn_id = str(info_df['Location ID'].values[0])
lat = float(info_df['Latitude'].values[0])
lon = float(info_df['Longitude'].values[0])
tz = int(info_df['Time Zone'].values[0])
ele = float(info_df['Elevation'].values[0])

# load minimal idf
idf_file = openstudio.IdfFile().load('min.idf').get()

# add site location idf object
ot = openstudio.IddObjectType('Site_Location')
no = openstudio.IdfObject(ot)
no.setString(0, locn_id)
no.setDouble(1, lat)
no.setDouble(2, lon)
no.setInt(3, tz)
no.setDouble(4, ele)
idf_file.addObject(no)

# save idf
idf_file.save('in.idf', True)