import pandas as pd
import csv

# read sam csv in two dataframes
sam_csv = '32.87_-117.15_32.87_-117.15_nsrdb-GOES-aggregated-v4-0-0_60_2018.csv'
info_df = pd.read_csv(sam_csv, nrows=1)
data_df = pd.read_csv(sam_csv, skiprows=2)

# get info for epw header
city = info_df['City'].values[0]
state = info_df['State'].values[0]
cntry = info_df['Country'].values[0]
src = info_df['Source'].values[0]
locn_id = info_df['Location ID'].values[0]
lat = info_df['Latitude'].values[0]
lon = info_df['Longitude'].values[0]
tz = info_df['Time Zone'].values[0]
ele = info_df['Elevation'].values[0]

# write epw header
epw_file = open('in.epw', 'w', newline='\n', encoding='utf-8')
epw_file.write(f'LOCATION,{city},{state},{cntry},{src},{locn_id},{lat},{lon},{tz},{ele}\n')
epw_file.write('DESIGN CONDITIONS,0\n')
epw_file.write('TYPICAL/EXTREME PERIODS,0\n')
epw_file.write('GROUND TEMPERATURES,0\n')
epw_file.write('HOLIDAYS/DAYLIGHT SAVINGS,No,0,0,0\n')
epw_file.write('COMMENTS 1,\n')
epw_file.write('COMMENTS 2,\n')
epw_file.write(f'DATA PERIODS,1,1,Data,Sunday,1/1,12/31\n')

# define epw writer
writer = csv.writer(epw_file, delimiter=',', lineterminator='\n')

# write each row of data df in epw format
for i in range(data_df.shape[0]):

    # calculate opaque sky cover
    if data_df['Clearsky DNI'][i] == 0:
        osc = 5
    else:
        osc = data_df['DNI'][i] / data_df['Clearsky DNI'][i]

    # build epw row
    row = [
        data_df['Year'][i],
        data_df['Month'][i],
        data_df['Day'][i],
        data_df['Hour'][i] + 1, # e+ expects hour to start at 1
        data_df['Minute'][i] - 30, # e+ expects minute to start at 0
        '?9?9?9?9E0?9?9?9?9?9?9?9?9?9?9?9?9?9?9?9*9*9?9*9*9',
        data_df['Temperature'][i],
        data_df['Dew Point'][i],
        data_df['Relative Humidity'][i],
        data_df['Pressure'][i] * 100, # convert mbar to pa
        '9999',
        '9999',
        '9999',
        data_df['GHI'][i],
        data_df['DNI'][i],
        data_df['DHI'][i],
        '999999',
        osc,
        '999999',
        '9999',
        data_df['Wind Direction'][i],
        data_df['Wind Speed'][i],
        '99',
        '99',
        '9999',
        '99999',
        '9',
        '999999999',
        '999',
        '0.999',
        '0',
        '88',
        data_df['Surface Albedo'][i],
        '999',
        '99'
    ]

    # write epw row
    writer.writerow(row)

# close epw
epw_file.close()
